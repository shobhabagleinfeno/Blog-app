// File: controllers/blogController.js

const Blog = require('../models/Blog');

// Get all blogs
exports.getAllBlogs = async (req, res) => {
  try {
    const blogs = await Blog.find();
    res.render('blogs/index', { blogs });
  } catch (err) {
    res.status(500).send(err.message);
  }
};

// Render form to create new blog
exports.renderNewBlogForm = (req, res) => {
  res.render('blogs/new');
};

// Create new blog
exports.createBlog = async (req, res) => {
  try {
    const blog = new Blog(req.body);
    await blog.save();
    res.redirect('/blogs');
  } catch (err) {
    res.status(400).send(err.message);
  }
};

// Get single blog by ID
exports.getBlogById = async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    res.render('blogs/show', { blog });
  } catch (err) {
    res.status(404).send('Blog not found');
  }
};

// Render form to edit blog
exports.renderEditBlogForm = async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    res.render('blogs/edit', { blog });
  } catch (err) {
    res.status(404).send('Blog not found');
  }
};

// Update blog
exports.updateBlog = async (req, res) => {
  try {
    await Blog.findByIdAndUpdate(req.params.id, req.body);
    res.redirect(`/blogs/${req.params.id}`);
  } catch (err) {
    res.status(400).send(err.message);
  }
};

// Delete blog
exports.deleteBlog = async (req, res) => {
  try {
    await Blog.findByIdAndDelete(req.params.id);
    res.redirect('/blogs');
  } catch (err) {
    res.status(500).send(err.message);
  }
};
